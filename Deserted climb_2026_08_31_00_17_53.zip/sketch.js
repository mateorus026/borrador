let noelleW = [];
let noelleS = [];
let noelleJ = [];
let noelleD = [];

let maus;
let queso;
let fondo;

let deltaruneF;

let frameIndice = 0;   
let ultimoTiempo = 0;    
let velocidadAnimacionMs = 150;

// Posicion y limites de Noelle
let posX = 117;
let posY = 610;

let velocidadMovimiento = 2.0; 
let velocidadRapida = 6.0;    
let limiteArriba = 310; 
let limiteDerecha = 326; 
let limiteIzquierda = 122; 
let limiteAbajo = 610;    

// Variables y estado de Maus
let mausX = 800;
let mausY = 356;
let mausVelocidad = 2.5;
let mausVelocidadEscape = 4.0;
let mausDestinoX = 592;

let quesoX = 536;
let quesoY = 334;

let estadoMaus = "ESPERANDO_SALTO";
let tiempoEsperaMaus = 0;
let duracionPausaMs = 2000; 

let estado = "SUBIR"; 

function preload() {
  // Carga de animaciones asegurando la asignacion del array
  cargarAnimacion("noelleW", 4, noelleW);
  cargarAnimacion("noelleS", 4, noelleS);
  cargarAnimacion("noelleJ", 12, noelleJ);
  cargarAnimacion("noelleD", 4, noelleD);
  
  maus = loadImage("maus.png");
  queso = loadImage("cheese.png");
  fondo = loadImage("noelleroom.png");
  
  // Si la fuente falla en cargar, p5.js usara la fuente por defecto
  try {
    deltaruneF = loadFont("deltarune.ttf");
  } catch (e) {
    console.log("No se pudo cargar la fuente deltarune.ttf, usando fuente predeterminada.");
  }
}

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(0);
  
  if (fondo) {
    image(fondo, -12, -12, 820, 620);
  }
  
  controlarMaus();
  controlarEstado();
}

// Carga las imagenes directamente en el array especificado
function cargarAnimacion(prefijo, cantidadFrames, arrayDestino) {
  for (let i = 0; i < cantidadFrames; i++) {
    arrayDestino[i] = loadImage(prefijo + i + ".png");
  }
}

// Logica del maus y el queso
function controlarMaus() {
  switch (estadoMaus) {
    case "ESPERANDO_SALTO":
      if (queso) image(queso, quesoX, quesoY, 60, 75);
      if (estado === "SALTO") {
        estadoMaus = "IR_AL_QUESO";
      }
      break;

    case "IR_AL_QUESO":
      if (queso) image(queso, quesoX, quesoY, 60, 75);
      if (mausX > mausDestinoX) {
        mausX -= mausVelocidad;
      } else {
        estadoMaus = "ESPERAR_TIEMPO";
        tiempoEsperaMaus = millis();
      }
      if (maus) image(maus, mausX, mausY, 60, 40);
      break;

    case "ESPERAR_TIEMPO":
      if (queso) image(queso, quesoX, quesoY, 60, 75);
      if (maus) image(maus, mausX, mausY, 60, 40);
      if (millis() - tiempoEsperaMaus > duracionPausaMs) {
        estadoMaus = "ESCAPAR_CON_QUESO";
      }
      break;

    case "ESCAPAR_CON_QUESO":
      mausX += mausVelocidadEscape;
      quesoX = mausX - 15;

      if (mausX <= width) {
        if (queso) image(queso, quesoX, quesoY, 60, 75);
        if (maus) reproducirInvertidoEstatico(maus, mausX, mausY, 60, 40);
      }
      break;
  }
}

// Control de estados de Noelle y mensaje final
function controlarEstado() {
  switch (estado) {
    case "SUBIR":
      if (posY > limiteArriba) {
        posY -= velocidadMovimiento;
        reproducirAnimacion(noelleW, posX, posY, velocidadAnimacionMs);
      } else {
        cambiarEstado("DERECHA"); 
      }
      break;
      
    case "DERECHA":
      if (posX < limiteDerecha) {
        posX += velocidadMovimiento; 
        reproducirAnimacion(noelleD, posX, posY, velocidadAnimacionMs);
      } else {
        cambiarEstado("SALTO");
      }
      break;
      
    case "SALTO":
      reproducirAnimacion(noelleJ, posX, posY, 100); 
      if (esUltimoFrame(noelleJ, frameIndice)) {
        cambiarEstado("IZQUIERDA");
      }
      break;
      
    case "IZQUIERDA":
      if (posX > limiteIzquierda) {
        posX -= velocidadRapida; 
        reproducirAnimacionInvertida(noelleD, posX, posY, 60); 
      } else {
        cambiarEstado("BAJAR"); 
      }
      break;

    case "BAJAR":
      if (posY < limiteAbajo) {
        posY += velocidadRapida; 
        reproducirAnimacion(noelleS, posX, posY, 60); 
      } else {
        cambiarEstado("DETENIDO");
      }
      break;
      
    case "DETENIDO":
      if (noelleS[0]) {
        image(noelleS[0], posX, posY, 80, 100); 
      }
      
      if (mausX > width) {
        mostrarTextoContinuar();
      }
      break;
  }
}

function mostrarTextoContinuar() {
  if (deltaruneF) {
    textFont(deltaruneF);
  }
  textSize(32);
  textAlign(CENTER, CENTER);
  
  let xCentrado = width / 2;
  let yCentrado = height - 60;
  
  // Sombra
  fill(0);
  text("Presionar R para reiniciar", xCentrado + 2, yCentrado + 2);
  
  // Texto principal
  fill(39, 255, 242);
  text("Presionar R para reiniciar", xCentrado, yCentrado);
}

// Funciones de reproduccion y control
function reproducirAnimacion(animArray, x, y, intervaloMs) {
  if (!animArray || animArray.length === 0) return;
  
  if (millis() - ultimoTiempo > intervaloMs) {
    frameIndice = (frameIndice + 1) % animArray.length;
    ultimoTiempo = millis();
  }
  
  if (animArray[frameIndice]) {
    image(animArray[frameIndice], x, y, 80, 100);
  }
}

function reproducirAnimacionInvertida(animArray, x, y, intervaloMs) {
  if (!animArray || animArray.length === 0) return;

  if (millis() - ultimoTiempo > intervaloMs) {
    frameIndice = (frameIndice + 1) % animArray.length;
    ultimoTiempo = millis();
  }
  
  if (animArray[frameIndice]) {
    push();
    translate(x + 80, y); 
    scale(-1, 1);         
    image(animArray[frameIndice], 0, 0, 80, 100);
    pop();
  }
}

function reproducirInvertidoEstatico(img, x, y, w, h) {
  push();
  translate(x + w, y);
  scale(-1, 1);
  image(img, 0, 0, w, h);
  pop();
}

function cambiarEstado(nuevoEstado) {
  estado = nuevoEstado;
  frameIndice = 0; 
  ultimoTiempo = millis();
}

function esUltimoFrame(animArray, indiceActual) {
  return indiceActual === animArray.length - 1;
}

// Reinicio
function keyPressed() {
  if ((key === 'r' || key === 'R') && estado === "DETENIDO" && mausX > width) {
    posX = 117;
    posY = 610;
    
    mausX = 800;
    quesoX = 536;
    quesoY = 334;
    estadoMaus = "ESPERANDO_SALTO";
    
    cambiarEstado("SUBIR");
  }
}